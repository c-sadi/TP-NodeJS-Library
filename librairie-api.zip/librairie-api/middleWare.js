const jwt = require('jsonwebtoken');

// Middleware pour vérifier le token //
exports.verifyToken = (req, res, next) => {
    try {
        const token = req.headers.authorization.split(' ')[1];
        // décoder le token //

        const decoded = jwt.verify(token, process.env.JWT_SECRET);

        // Ajouter les données de l'utilisateur //

        req.user = decoded;

        next();
    } catch (error) {
    
        res.status(401).send("Invalid token");
    }
};

// Middleware pour les données des utilisateurs (rôles) //
exports.authorizeRoles = (roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return res.status(403).send('Access denied');
        }
    
        next();
    };
};
