const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const AppError = require('../utils/appError');
const catchAsync = require('../utils/catchAsync');
const User = require('../models/userModel');


// Création du JWT //

const signToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN,
    });
  };

// Envoi du JWT au User //
const createSendToken = (user, statusCode, res) => {
    const token = signToken(user._id);
  
    const cookieOptions = {
      expires: new Date(
        Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 24 * 60 * 60 * 1000
      ),
      // Le cookie ne peut pas être modifié par le navigateur
      httpOnly: true,
    };
  
    // Sécuriser le cookie//

    if (process.env.NODE_ENV === 'production') cookieOptions.secure = true;
  
    res.cookie('jwt', token, cookieOptions);
  
    // On retire le mot de passe 
    user.password = undefined;
  
    res.status(statusCode).json({
      status: 'success',
      token,
      data: {
        user,
      },
    });
  };
  

//fonction d'inscription//

exports.signup = catchAsync(async function (req, res) {
    const newUser = await User.create({
      name: req.body.name,
      email: req.body.email,
      password: req.body.password,
      passwordConfirm: req.body.passwordConfirm,
    });

// vérification du mot de passe //
    if (password !== passwordConfirm) {
     return next(new AppError('Passwords do not match', 400));}
      
// Hasher le mot de passe avec bcrypt  //
const hashedPassword = await bcrypt.hash(password, 12);
  
    createSendToken(newUser, 201, res);
  });

// générer un token JWT //
  const token = jwt.sign({ userId: newUser._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN
  });

  // Envoyer la réponse avec le token JWT
  res.status(201).json({
    status: 'success',
    token,
    data: { user: newUser }
  });

  //fonction de connexion//

exports.login = catchAsync(async function (req, res, next) {
    const { email, password } = req.body;
  
    // 1) Vérifier si l'email et le mot de passe ont été envoyés par l'utilisateur
    if (!email || !password) {
      return next(new AppError('Please provide email and password', 400));
    }
  
    // 2) Vérifier si l'utilisateur existe et si le mot de passe est correct
    const user = await User.findOne({ email }).select('+password');
  
    const correct = await user.correctPassword(password, user.password);
  
    if (!user || !correct) {
      return next(new AppError('Incorrect email or password', 401));
    }
    createSendToken(user, 200, res);
});



